exports.printMsg = function() {
  console.log("This is from my module")
}
